/* Author: David Rivera
 * Set arm to default position at (1, 9), in between moves
 * Uses <setOrigin()> and <movePieceSimult(uint16_t nextX, uint16_t nextY)> to control arm
 * All other movement functions include more safety contingencies, but are unneeded
 * Flesh out draw clock and touch screen interrupt for menu control
*/

#include <F28x_Project.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "gpio.h"
#include "interrupt.h"
#include "cputimer.h"
#include "LCDLib.h"
#include "STEPPERm_LIB.h"
#include "chess.h"

#define DEVICE_SYSCLK_FREQ  200000000

__interrupt void RX_MCBSPB_isr();
__interrupt void TIMER0_isr(void);
__interrupt void TIMER1_isr(void);
__interrupt void TIMER2_isr(void);
__interrupt void XINT1_isr();
__interrupt void XINT2_isr();
__interrupt void XINT3_isr();
__interrupt void XINT4_isr();
__interrupt void XINT5_isr();

void setOrigin();   //return plunger to origin

uint16_t movePiece(uint16_t currX, uint16_t currY, uint16_t nextX, uint16_t nextY);
uint16_t movePieceSimult(uint16_t nextX, uint16_t nextY);

void movePlungerFromTo(uint16_t *currPosPlunger, uint16_t newPosPlunger, volatile bool *mutex);
uint8_t movePlungerTurns(uint16_t turns, dir direction, volatile bool *mutex);
void moveArmFromTo(uint16_t *currPosArm, uint16_t newPosArm, volatile bool *mutex);
uint8_t moveArmTurns(uint16_t turns, dir direction, volatile bool *mutex);

void goToOriginPlunger();           //sends plunger to its origin (left limit switch)
void OriginPlunger_RESET();         //gets plunger off the left limit switch
void goToOriginPlunger_RESET();     //sends plunger to its origin AND gets arm off the left limit switch
void goToLimitPlunger_RESET();      //sends plunger to right limit switch AND gets plunger off the front limit switch

void goToOriginArm();               //sends arm to its origin (back limit switch)
void OriginArm_RESET();             //gets arm off the back limit switch
void goToOriginArm_RESET();         //sends arm to its origin AND gets arm off the back limit switch
void goToLimitArm_RESET();          //sends arm to front limit switch AND gets arm off the front limit switch

void drawClock(uint16_t Color);                     //Draw the clock on the LCD
void pause_start_game(bool *pause_start_toggle);    //Pause and start the game

/* STEPPER GLOBAL VARIABLES */
volatile bool mutex_M0;
volatile bool mutex_M1M2;
bool back_sw_pressed;
bool forward_sw_pressed;
bool left_sw_pressed;
bool right_sw_pressed;
uint32_t numOfSteps             = 0;
uint32_t numOfStepsA4988        = 0;
uint16_t currPosArm             = 0;
uint16_t currPosPlunger         = 0;
uint16_t readReg                = 0;
uint16_t xint1CNT               = 0;
uint16_t xint2CNT               = 0;
uint16_t xint3CNT               = 0;
uint16_t xint4CNT               = 0;

/* LCD & TOUCHSCREEN GLOBAL VARIABLES*/
char readByte;
char chipId[2]      = {0x00, 0x00};
char dataXY[4]      = {0x00, 0x00, 0x00, 0x00};

uint32_t tchScrnCnt = 0;
uint16_t posXY      = 0;
uint16_t X          = 0;
uint16_t Y          = 0;
uint16_t prevX      = 0;
uint16_t prevY      = 0;
uint16_t rawX       = 0;
uint16_t rawY       = 0;

uint16_t prevMinutes    = 0;
uint16_t prevSeconds    = 0;
uint16_t minutes    = 0;
uint16_t seconds    = 0;

bool pause_start_toggle;
bool pause_start_FLG;
bool drawTheClock;

char chessPieces[8][8];
char newChessPieces[8][8];

chessPiece chessStates;
bool chessStateTog;

int main(void)
{
    EALLOW;
    InitSysCtrl();
    EALLOW;
    DELAY_US(100);
//    InitSPIA();                                         //Initialize SPIA to send data to Codec
//    InitMcBSPb();                                       //Initialize McBSP system
//    InitAIC23(false);                                   //Configure Codec

    /* INITIALIZE STEPPER MOTOR*/
    stepper_init_spib();
    stepper_init_settings();

    /* Initialize Touchscreen */
    LCD_initGPIO();
    LCD_Init();
    drawClock(LCD_WHITE);
    initChessPieces(&chessPieces);
    initChessPieces(&newChessPieces);
    drawPieces(&chessPieces);
    drawClock(LCD_BLACK);
    TCHSCRN_I2C_LCD_init();

    Interrupt_initModule();                             //Enable interrupt module
    Interrupt_initVectorTable();                        //Enable interrupt vector table

    //Initialize MCBSPB Interrupt
//    Interrupt_register(INT_MCBSPB_RX, &RX_MCBSPB_isr);  //Location of INT_MCBSPB_RX isr loaded

    //Initialize TIMER0 Interrupt for DRV8771
    Interrupt_register(INT_TIMER0, &TIMER0_isr);
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_setPeriod(CPUTIMER0_BASE, (uint32_t)(DEVICE_SYSCLK_FREQ * STEPPER_HI_PERIOD));
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0);   //no prescaler
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_setEmulationMode(CPUTIMER0_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);

    /* Initialize TIMER1 Interrupt for A4988 */
    Interrupt_register(INT_TIMER1, &TIMER1_isr);
    CPUTimer_stopTimer(CPUTIMER1_BASE);
    CPUTimer_setPeriod(CPUTIMER1_BASE, (uint32_t)(DEVICE_SYSCLK_FREQ * STEPPER_LO_PERIOD));
    CPUTimer_setPreScaler(CPUTIMER1_BASE, 0);   //no prescaler
    CPUTimer_reloadTimerCounter(CPUTIMER1_BASE);
    CPUTimer_setEmulationMode(CPUTIMER1_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER1_BASE);

    /* Initialize TIMER2 Interrupt for clock */
     Interrupt_register(INT_TIMER2, &TIMER2_isr);
     CPUTimer_stopTimer(CPUTIMER2_BASE);
     CPUTimer_setPeriod(CPUTIMER2_BASE, (uint32_t)(DEVICE_SYSCLK_FREQ * 1));
     CPUTimer_setPreScaler(CPUTIMER2_BASE, 0);                           //no prescaler
     CPUTimer_reloadTimerCounter(CPUTIMER2_BASE);
     CPUTimer_setEmulationMode(CPUTIMER2_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
     CPUTimer_enableInterrupt(CPUTIMER2_BASE);

    /* Initialize XINT1 for back switch */
    Interrupt_register(INT_XINT1, &XINT1_isr);
    GPIO_setDirectionMode(LIMSW_XINT1_PIN, GPIO_DIR_MODE_IN);            // input
    GPIO_setQualificationMode(LIMSW_XINT1_PIN, GPIO_QUAL_SYNC);
    GPIO_setQualificationPeriod(3,510);
    GPIO_setInterruptPin(LIMSW_XINT1_PIN, GPIO_INT_XINT1);
    GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT1);         // Enable XINT1

    /* Initialize XINT2 for front switch */
    Interrupt_register(INT_XINT2, &XINT2_isr);
    GPIO_setDirectionMode(LIMSW_XINT2_PIN, GPIO_DIR_MODE_IN);            // input
    GPIO_setQualificationMode(LIMSW_XINT2_PIN, GPIO_QUAL_SYNC);
    GPIO_setQualificationPeriod(3,510);
    GPIO_setInterruptPin(LIMSW_XINT2_PIN, GPIO_INT_XINT2);
    GPIO_setInterruptType(GPIO_INT_XINT2, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT2);         // Enable XINT1

    /* Initialize XINT3 for left switch */
    Interrupt_register(INT_XINT3, &XINT3_isr);
    GPIO_setDirectionMode(LIMSW_XINT3_PIN, GPIO_DIR_MODE_IN);
    GPIO_setQualificationMode(LIMSW_XINT3_PIN, GPIO_QUAL_SYNC);
    GPIO_setQualificationPeriod(3,510);
    GPIO_setInterruptPin(LIMSW_XINT3_PIN, GPIO_INT_XINT3);
    GPIO_setInterruptType(GPIO_INT_XINT3, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT3);

    /* Initialize XINT4 for right switch */
    Interrupt_register(INT_XINT4, &XINT4_isr);
    GPIO_setDirectionMode(LIMSW_XINT4_PIN, GPIO_DIR_MODE_IN);
    GPIO_setQualificationMode(LIMSW_XINT4_PIN, GPIO_QUAL_SYNC);
    GPIO_setQualificationPeriod(3,510);
    GPIO_setInterruptPin(LIMSW_XINT4_PIN, GPIO_INT_XINT4);
    GPIO_setInterruptType(GPIO_INT_XINT4, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT4);

    /* Initialize XINT5 */
    GPIO_setDirectionMode(59, GPIO_DIR_MODE_IN);
    GPIO_setQualificationMode(59, GPIO_QUAL_SYNC);
    GPIO_setQualificationPeriod(59,510);
    GPIO_setInterruptPin(59, GPIO_INT_XINT5);
    GPIO_setInterruptType(GPIO_INT_XINT5, GPIO_INT_TYPE_RISING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT5);                               // Enable XINT5
    Interrupt_register(INT_XINT5, &XINT5_isr);

    /* Enable Interrupts */
    Interrupt_enable(INT_TIMER0);
    Interrupt_enable(INT_TIMER1);
    Interrupt_enable(INT_TIMER2);
    Interrupt_enable(INT_XINT1);
    Interrupt_enable(INT_XINT2);
    Interrupt_enable(INT_XINT3);
    Interrupt_enable(INT_XINT4);
    Interrupt_enable(INT_XINT5);
    Interrupt_enableMaster();
//    Interrupt_enable(INT_MCBSPB_RX);

    newChessPieces[4][5]  = 'P';
    newChessPieces[6][5]  = '.';
    setOrigin();

    /* Start TIMER2 for Clock*/
    CPUTimer_startTimer(CPUTIMER2_BASE);


    while(1){
        movePieceSimult(8,1);
        movePieceSimult(8,8);
        movePieceSimult(1,1);
        movePieceSimult(1,8);
    }
}

__interrupt void RX_MCBSPB_isr(){
    McbspbRegs.DXR2.all = McbspbRegs.DRR2.all;
    McbspbRegs.DXR1.all = McbspbRegs.DRR1.all;
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP6);
}

__interrupt void XINT1_isr(){
    GPIO_disableInterrupt(GPIO_INT_XINT1);
    //DISABLE MOTOR HERE
    xint1CNT++;
    DELAY_US(80000);            //80ms debounce wait

    if(!GpioDataRegs.GPADAT.bit.GPIO10){
        CPUTimer_stopTimer(CPUTIMER1_BASE);
        numOfStepsA4988     = 0;
        mutex_M1M2          = false;

        back_sw_pressed     = true;
    }

    DELAY_US(80000);            //80ms debounce wait
    GPIO_enableInterrupt(GPIO_INT_XINT1);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

__interrupt void XINT2_isr(){
    GPIO_disableInterrupt(GPIO_INT_XINT2);
    //DISABLE MOTOR HERE
    xint2CNT++;
    DELAY_US(80000);                    //80ms debounce wait

    if(!GpioDataRegs.GPADAT.bit.GPIO11){
        CPUTimer_stopTimer(CPUTIMER1_BASE);
        numOfStepsA4988     = 0;
        mutex_M1M2          = false;

        forward_sw_pressed  = true;
    }

    DELAY_US(80000);            //80ms debounce wait
    GPIO_enableInterrupt(GPIO_INT_XINT2);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

__interrupt void XINT3_isr(){
    GPIO_disableInterrupt(GPIO_INT_XINT3);
    //DISABLE MOTOR HERE
    DELAY_US(80000);            //80ms debounce wait

    if(!GpioDataRegs.GPCDAT.bit.GPIO75){
        xint3CNT++;
        CPUTimer_stopTimer(CPUTIMER0_BASE);
        numOfSteps          = 0;
        mutex_M0            = false;
        left_sw_pressed     = true;
    }

    DELAY_US(80000);            //80ms debounce wait
    GPIO_enableInterrupt(GPIO_INT_XINT3);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}

__interrupt void XINT4_isr(){
    GPIO_disableInterrupt(GPIO_INT_XINT4);
    //DISABLE MOTOR HERE
    DELAY_US(80000);                    //80ms debounce wait

    if(!GpioDataRegs.GPCDAT.bit.GPIO76){
        xint4CNT++;
        CPUTimer_stopTimer(CPUTIMER0_BASE);
        numOfSteps          = 0;
        mutex_M0            = false;
        right_sw_pressed    = true;
    }

    DELAY_US(80000);            //80ms debounce wait
    GPIO_enableInterrupt(GPIO_INT_XINT4);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}

__interrupt void XINT5_isr(){
    Interrupt_disable(INT_XINT5);
    readByte        = TCHSCRN_I2C_ReadByte(STMPE_INT_STA);
    if(readByte & 0x01){
        tchScrnCnt++;
        readByte        = TCHSCRN_I2C_ReadByte(STMPE_FIFO_STA);
        while(!((readByte>>5) & 0x01)){             //read data until FIFO empty
            posXY       = TCHSCRN_I2C_ReadBytes(STMPE_TSC_DATA, dataXY, sizeof(dataXY));
            readByte    = TCHSCRN_I2C_ReadByte(STMPE_FIFO_STA);
        }
        X = (uint16_t)((((dataXY[1] & 0x0F)<<8) | dataXY[2]) * 0.09);
        Y = (uint16_t)(((dataXY[0] << 4) | (dataXY[1]  >> 4)) * 0.09);

        if(((prevX != X) || (prevY != Y))){
            if((X >= 40 && X <= 120) && (Y >= 90 && Y <= 145)){
                if(chessStateTog == 0){
                    updatePieces(&chessPieces, &newChessPieces);
                    chessStateTog = true;
                }
            }else if((X >= 40 && X <= 120) && (Y >= 175 && Y <= 230)){
                if(chessStateTog == 1){
                    updatePieces(&newChessPieces, &chessPieces);
                    chessStateTog = false;
                }
            }else if((X >= 40 && X <= 120) && (Y >= 275 && Y <= 320)){
                pause_start_game(&pause_start_toggle);
                pause_start_toggle ^= 1;
            }
        }
        prevX = X;
        prevY = Y;
        TCHSCRN_I2C_SendByte(STMPE_INT_STA, 0xFF);        //Clear status flags

        Interrupt_enable(INT_XINT5);
    }else{
        Interrupt_enable(INT_XINT5);
    }
//    DELAY_US(100000);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}

__interrupt void TIMER0_isr(void){
    if (numOfSteps > 0){
        M0_STEP;
        numOfSteps--;
    }else{
        CPUTimer_stopTimer(CPUTIMER0_BASE);
        mutex_M0 = false;
    }
//    M0_STEP;
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

__interrupt void TIMER1_isr(void){
    if (numOfStepsA4988 > 0){
        M1M2_STEP;
        numOfStepsA4988--;
    }else{
        CPUTimer_stopTimer(CPUTIMER1_BASE);
        mutex_M1M2 = false;
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

__interrupt void TIMER2_isr(void){
//    drawClock(LCD_BLACK);
    seconds++;
    if (seconds == 60){
        minutes++;
        if(minutes == 100){
            minutes = 0;
        }
        seconds = 0;
    }
    if(!drawTheClock){
        drawTheClock = 1;
    }
//    drawClock(LCD_WHITE);
}


void goToOriginArm_RESET(){
    while(back_sw_pressed == false){
       while(!stepper_moveA4988(&numOfStepsA4988, SIXTEENTH_TURN, BWD, &mutex_M1M2));
    }
    DELAY_US(80000);
    /* get off switch */
    while(!GpioDataRegs.GPADAT.bit.GPIO10){
       DELAY_US(80000);
       while(!stepper_moveA4988(&numOfStepsA4988, EIGTH_TURN, FWD, &mutex_M1M2));
    }
    DELAY_US(800000);
    forward_sw_pressed = false;
    back_sw_pressed = false;
}

void goToLimitArm_RESET(){
    while(forward_sw_pressed == false){
       stepper_moveA4988(&numOfStepsA4988, SIXTEENTH_TURN, FWD, &mutex_M1M2);
    }
    DELAY_US(80000);
    /* get off switch */
    while(!GpioDataRegs.GPADAT.bit.GPIO11){
       DELAY_US(80000);
       stepper_moveA4988(&numOfStepsA4988, EIGTH_TURN, BWD, &mutex_M1M2);
    }
    DELAY_US(800000);
    forward_sw_pressed = false;
    back_sw_pressed = false;
}


void goToOriginArm(){
    while(back_sw_pressed == false){
       while(!stepper_moveA4988(&numOfStepsA4988, SIXTEENTH_TURN, BWD, &mutex_M1M2));
    }
    DELAY_US(80000);
    forward_sw_pressed = false;
}

void OriginArm_RESET(){
    /* get off switch */
    while(!GpioDataRegs.GPADAT.bit.GPIO10){
       DELAY_US(80000);
       while(!stepper_moveA4988(&numOfStepsA4988, EIGTH_TURN, FWD, &mutex_M1M2));
    }
    DELAY_US(800000);
    back_sw_pressed = false;
}

void moveArmFromTo(uint16_t *currPosArm, uint16_t newPosArm, volatile bool *mutex){
    int16_t posDiff = 0;                //position difference
    if(newPosArm > 10 || newPosArm < 1){
        return;
    }else{
        posDiff = newPosArm - *currPosArm;
        if(posDiff > 0){
            if(!moveArmTurns(posDiff*SQUARE_LENGTH, BWD, mutex)){
                return;
            }
        }else if(posDiff < 0){
            posDiff = -1*posDiff;
           if(!moveArmTurns(posDiff*SQUARE_LENGTH, FWD, mutex)){
               return;
           }
        }
        *currPosArm = newPosArm;
    }
}

uint8_t moveArmTurns(uint16_t turns, dir direction, volatile bool *mutex){
    uint16_t numberOfHalfTurns = turns;

    stepper_mutex_delay(mutex);
    while(numberOfHalfTurns > 0){
        if(forward_sw_pressed){
            stepper_mutex_delay(mutex);
            goToOriginArm();
        }else if(back_sw_pressed){
            stepper_mutex_wait(mutex);
            OriginArm_RESET();
            numberOfHalfTurns = 0;
            return 0;
        }else{
            stepper_mutex_wait(mutex);
            stepper_moveA4988(&numOfStepsA4988, HALF_TURN, direction, mutex);
            numberOfHalfTurns--;
        }
    }
    return 1;
}

void movePlungerFromTo(uint16_t *currPosPlunger, uint16_t newPosPlunger, volatile bool *mutex){
    int16_t posDiff = 0;                //position difference
    if(newPosPlunger > 8 || newPosPlunger < 1){
        return;
    }else{
        posDiff = newPosPlunger - *currPosPlunger;
        if(posDiff > 0){
            if(!movePlungerTurns(posDiff*SQUARE_LENGTH, FWD, mutex)){
                return;
            }
        }else if(posDiff < 0){
            posDiff = -1*posDiff;
            if(!movePlungerTurns(posDiff*SQUARE_LENGTH, BWD, mutex)){   //quit if reached end ERROR!
                return;
            }
        }
        *currPosPlunger = newPosPlunger;    //reassign new position if successful
    }
}

uint8_t movePlungerTurns(uint16_t turns, dir direction, volatile bool *mutex){
    uint16_t numberOfHalfTurns = turns;
    stepper_mutex_delay(mutex);
    while(numberOfHalfTurns > 0){
        if(right_sw_pressed){
            stepper_mutex_delay(mutex);
            goToOriginPlunger();
        }else if(left_sw_pressed){
            stepper_mutex_wait(mutex);
            OriginPlunger_RESET();
            numberOfHalfTurns = 0;
            return 0;
        }else{
            stepper_mutex_wait(mutex);
            stepper_move(&numOfSteps, HALF_TURN, direction, mutex);
            numberOfHalfTurns--;
        }
    }
    return 1;
}

void goToOriginPlunger(){
    while(left_sw_pressed == false){
       while(!stepper_move(&numOfSteps, SIXTEENTH_TURN, BWD, &mutex_M0));
    }
    DELAY_US(80000);
    right_sw_pressed = false;
}

void OriginPlunger_RESET(){
    /* get off switch */
    while(!GpioDataRegs.GPCDAT.bit.GPIO75){
       DELAY_US(80000);
       while(!stepper_move(&numOfSteps, EIGTH_TURN, FWD, &mutex_M0));
    }
    DELAY_US(800000);
    left_sw_pressed = false;
}

void goToOriginPlunger_RESET(){
    while(left_sw_pressed == false){
       while(!stepper_move(&numOfSteps, SIXTEENTH_TURN, BWD, &mutex_M0));
    }
    DELAY_US(80000);
    /* get off switch */
    while(!GpioDataRegs.GPCDAT.bit.GPIO75){
       DELAY_US(80000);
       while(!stepper_move(&numOfSteps, EIGTH_TURN, FWD, &mutex_M0));
    }
    DELAY_US(800000);
    right_sw_pressed = false;
    left_sw_pressed = false;
}

void goToLimitPlunger_RESET(){
    while(right_sw_pressed == false){
       stepper_move(&numOfSteps, SIXTEENTH_TURN, FWD, &mutex_M0);
    }
    DELAY_US(80000);
    /* get off switch */
    while(!GpioDataRegs.GPCDAT.bit.GPIO76){
       DELAY_US(80000);
       stepper_move(&numOfSteps, EIGTH_TURN, BWD, &mutex_M0);
    }
    DELAY_US(800000);
    right_sw_pressed = false;
    left_sw_pressed = false;
}

void setOrigin(){
    goToOriginArm_RESET();
    moveArmTurns(BOARD_ORIGIN_ARM, FWD, &mutex_M1M2);
    goToOriginPlunger_RESET();
    movePlungerTurns(BOARD_ORIGIN_PLUNGER, FWD, &mutex_M0);

    currPosArm      = 8;    //arm is in first square
    currPosPlunger  = 1;    //plunger to first square
}

/*
 * NICE AND SLOW
 * X relates to the plunger
 * Y relates to the arm
*/
uint16_t movePiece(uint16_t currX, uint16_t currY, uint16_t nextX, uint16_t nextY){
    moveArmFromTo(&currPosArm, currY, &mutex_M1M2);
    movePlungerFromTo(&currPosPlunger, currX, &mutex_M0);

    /* pick up piece here */
    DELAY_US(3000000);
    moveArmFromTo(&currPosArm, nextY, &mutex_M1M2);
    movePlungerFromTo(&currPosPlunger, nextX, &mutex_M0);

    return 1;
}


void drawClock(uint16_t Color){
    char timeBuff[5];
    uint16_t temp;

    temp            = prevMinutes/10;
    timeBuff[0]     = temp+48;
    timeBuff[1]     = (prevMinutes-temp*10)+48;

    temp            = prevSeconds/10;
    timeBuff[3]     = temp+48;
    timeBuff[4]     = (prevSeconds-temp*10)+48;

    timeBuff[2]     = ':';

    LCD_Text(BUTTON_OFFSET_X, Y8, timeBuff, 2, LCD_BLACK);

    temp            = minutes/10;
    timeBuff[0]     = temp+48;
    timeBuff[1]     = (minutes-temp*10)+48;

    temp            = seconds/10;
    timeBuff[3]     = temp+48;
    timeBuff[4]     = (seconds-temp*10)+48;

    timeBuff[2]     = ':';

    LCD_Text(BUTTON_OFFSET_X, Y8, timeBuff, 2, LCD_WHITE);
    prevMinutes = minutes;
    prevSeconds = seconds;
    drawTheClock    = 0;
}

void pause_start_game(bool *pause_start_toggle){
    if(*pause_start_toggle == false){
        CPUTimer_stopTimer(CPUTIMER2_BASE);
        LCD_DrawRectangleBrdr(BUTTON_OFFSET_X, BUTTON_OFFSET_X + BUTTON_LENGTH,
                              Y2+26, Y2+BUTTON_WIDTH+26, 3, LCD_BLUE, LCD_BLACK);
        LCD_Text(BUTTON_OFFSET_X, Y2+26, "PLAY", 2, LCD_BLACK);
    }else{
        CPUTimer_startTimer(CPUTIMER2_BASE);
        LCD_DrawRectangleBrdr(BUTTON_OFFSET_X, BUTTON_OFFSET_X + BUTTON_LENGTH,
                              Y2+26, Y2+BUTTON_WIDTH+26, 3, LCD_RED, LCD_BLACK);
        LCD_Text(BUTTON_OFFSET_X, Y2+26, "PAUSE", 2, LCD_BLACK);
    }
}

uint16_t movePieceSimult(uint16_t nextX, uint16_t nextY){
    stepper_mutex_delay(&mutex_M0);
    stepper_mutex_delay(&mutex_M1M2);
    int armPositionDiff = 0;                //position difference
    int plungerPositionDiff = 0;            //position difference

    if(nextX > 8 || nextX < 1){
        return 0;
    }
    if(nextY > 9 || nextY < 1){
        return 0;
    }

    armPositionDiff     = currPosArm - nextY;
    plungerPositionDiff = currPosPlunger - nextX;

    if(armPositionDiff > 0 && plungerPositionDiff > 0){
        stepper_move(&numOfSteps, HALF_TURN*SQUARE_LENGTH*plungerPositionDiff, BWD, &mutex_M0);
        stepper_moveA4988(&numOfStepsA4988, HALF_TURN*SQUARE_LENGTH*armPositionDiff, FWD, &mutex_M1M2);
    }else if(armPositionDiff > 0 && plungerPositionDiff < 0){
        plungerPositionDiff = -1 * plungerPositionDiff;
        stepper_move(&numOfSteps, HALF_TURN*SQUARE_LENGTH*plungerPositionDiff, FWD, &mutex_M0);
        stepper_moveA4988(&numOfStepsA4988, HALF_TURN*SQUARE_LENGTH*armPositionDiff, FWD, &mutex_M1M2);
    }else if(armPositionDiff < 0 && plungerPositionDiff > 0){
        armPositionDiff     = -1*armPositionDiff;
        stepper_move(&numOfSteps, HALF_TURN*SQUARE_LENGTH*plungerPositionDiff, BWD, &mutex_M0);
        stepper_moveA4988(&numOfStepsA4988, HALF_TURN*SQUARE_LENGTH*armPositionDiff, BWD, &mutex_M1M2);
    }else{
        armPositionDiff     = -1*armPositionDiff;
        plungerPositionDiff = -1 * plungerPositionDiff;
        stepper_move(&numOfSteps, HALF_TURN*SQUARE_LENGTH*plungerPositionDiff, FWD, &mutex_M0);
        stepper_moveA4988(&numOfStepsA4988, HALF_TURN*SQUARE_LENGTH*armPositionDiff, BWD, &mutex_M1M2);
    }
    currPosPlunger  = nextX;
    currPosArm      = nextY;

    return 1;
}

